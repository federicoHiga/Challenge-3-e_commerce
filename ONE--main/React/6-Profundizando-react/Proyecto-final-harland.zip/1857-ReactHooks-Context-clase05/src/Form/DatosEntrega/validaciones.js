export const validarInput = (input) => {
  return input.length > 3 ? true : false;
};
